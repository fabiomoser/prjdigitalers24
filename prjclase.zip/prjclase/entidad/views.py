from django.shortcuts import render
from django.http import HttpResponse
import sqlite3

def index(request):
    return HttpResponse('Hola mundo desde Django!!')

def acerca_de(request):
    return HttpResponse('Curso Digitalers - EducaciónIT - Telecom')

def clientes(request):
    conn = sqlite3.connect("contabilidad.sqlite")
    cliente = conn.cursor()
    cliente.execute("select nombre, edad from personas")
    html = """
            <html>
                <title>Listado de clientes</title>
                <table style="border: 1px solid">
                    <thead>
                    <tr>
                    <th>Cliente</th>
                    <th>Edad</th>
                    </tr>
                    </thead>
            """
    for nombre, edad in cliente.fetchall():
        html += "<tr><td>" + nombre + "</td><td>" + str(edad) + "</td></tr>"
    html += "</table></html>"
    conn.close()
    return HttpResponse(html)