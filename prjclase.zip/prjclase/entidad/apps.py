from django.apps import AppConfig


class EntidadConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'entidad'
